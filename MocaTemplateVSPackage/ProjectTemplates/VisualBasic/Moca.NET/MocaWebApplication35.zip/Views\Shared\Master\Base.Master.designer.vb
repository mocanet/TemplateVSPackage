﻿'------------------------------------------------------------------------------
' <自動生成>
'     このコードはツールによって生成されました。
'
'     このファイルへの変更は、以下の状況下で不正な動作の原因になったり、
'     コードが再生成されるときに損失したりします。 
' </自動生成>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class Base

	'''<summary>
	'''Head1 コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents Head1 As Global.System.Web.UI.HtmlControls.HtmlHead

	'''<summary>
	'''Head コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents Head As Global.System.Web.UI.WebControls.ContentPlaceHolder

	'''<summary>
	'''frmMain コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents frmMain As Global.System.Web.UI.HtmlControls.HtmlForm

	'''<summary>
	'''ScriptManager1 コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents ScriptManager1 As Global.System.Web.UI.ScriptManager

	'''<summary>
	'''pnlHidden コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents pnlHidden As Global.System.Web.UI.WebControls.Panel

	'''<summary>
	'''MainContent コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents MainContent As Global.System.Web.UI.WebControls.ContentPlaceHolder

	'''<summary>
	'''DebugManager1 コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents DebugManager1 As Global.Moca.Web.UI.DebugManager

	'''<summary>
	'''Scripts コントロール。
	'''</summary>
	'''<remarks>
	'''自動生成されたフィールド。
	'''変更するには、フィールドの宣言をデザイナー ファイルから分離コード ファイルに移動します。
	'''</remarks>
	Protected WithEvents Scripts As Global.System.Web.UI.WebControls.ContentPlaceHolder
End Class
