﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は、以下の属性セットによって 
' 制御されます。 アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。

' アセンブリの属性値を確認します
<Assembly: AssemblyTitle("$safeprojectname$")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("MiYABiS")> 
<Assembly: AssemblyProduct("$safeprojectname$")> 
<Assembly: AssemblyCopyright("Copyright ©  2011")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

' このプロジェクトが COM に公開される場合、次の GUID が typelib の ID になります
<Assembly: Guid("9423ee6e-1649-4a02-abc8-6ad1bf1a35e1")> 

' アセンブリのバージョン情報は、次の 4 つの値で構成されます:
'
'      メジャー バージョン
'      マイナー バージョン 
'      ビルド番号
'      リビジョン
'
' すべての値を指定するか、下のように '*' を使ってビルドおよびリビジョン番号を 
' 既定値にすることができます。
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
