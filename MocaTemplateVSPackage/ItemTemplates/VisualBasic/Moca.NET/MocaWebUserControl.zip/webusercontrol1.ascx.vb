Public Class $safeitemname$
	Inherits Moca.Web.UI.MocaUserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class