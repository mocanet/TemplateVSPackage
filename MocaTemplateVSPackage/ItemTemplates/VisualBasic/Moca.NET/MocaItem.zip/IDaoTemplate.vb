﻿
Imports Moca.Db.Attr

Namespace Db

    ''' <summary>
	''' $fileinputname$ データアクセスインタフェース
    ''' </summary>
    ''' <remarks></remarks>
    <Dao($ConnectionSettingsName$, GetType(Impl.$fileinputname$))> _
    Public Interface I$fileinputname$

    End Interface

End Namespace
