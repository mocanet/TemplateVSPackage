﻿
Imports Moca.Db.Attr

Namespace Db

    ''' <summary>
	''' $fileinputname$ データアクセスインタフェース
    ''' </summary>
    ''' <remarks></remarks>
    <Dao("app.configのconnectionStringsキー", GetType(Impl.$fileinputname$))> _
    Public Interface I$fileinputname$

    End Interface

End Namespace
