﻿
Imports Moca.Db

Namespace Db.Impl

    ''' <summary>
	''' $safeitemname$ データアクセス
	''' </summary>
    ''' <remarks></remarks>
    Public Class $safeitemname$
		Inherits AbstractDao
        Implements I$safeitemname$

	End Class

End Namespace
